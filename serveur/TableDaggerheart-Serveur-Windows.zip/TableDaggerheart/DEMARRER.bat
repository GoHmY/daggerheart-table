@echo off
cd /d "%~dp0"
echo Table Daggerheart : fermez cette fenetre pour arreter le serveur.
node\node.exe server.js
pause
