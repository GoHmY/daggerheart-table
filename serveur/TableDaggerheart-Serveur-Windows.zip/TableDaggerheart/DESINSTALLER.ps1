﻿#Requires -RunAsAdministrator
Stop-ScheduledTask -TaskName "Table Daggerheart" -ErrorAction SilentlyContinue
Unregister-ScheduledTask -TaskName "Table Daggerheart" -Confirm:$false -ErrorAction SilentlyContinue
Remove-NetFirewallRule -DisplayName "Table Daggerheart" -ErrorAction SilentlyContinue
Write-Host "Table Daggerheart desinstallee. Vos donnees restent dans le dossier data." -ForegroundColor Green
