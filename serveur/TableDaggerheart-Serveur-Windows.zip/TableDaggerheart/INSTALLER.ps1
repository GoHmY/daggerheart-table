﻿#Requires -RunAsAdministrator
# Installe la Table Daggerheart comme tache qui demarre avec Windows.
$dir = Split-Path -Parent $MyInvocation.MyCommand.Path
$cfg = Get-Content (Join-Path $dir "config.json") -Raw | ConvertFrom-Json
if ($cfg.mjCode -eq "change-moi") { Write-Host "Ouvrez config.json et changez mjCode avant d'installer." -ForegroundColor Red; exit 1 }
$port = [int]$cfg.port
$node = Join-Path $dir "node\node.exe"
Remove-NetFirewallRule -DisplayName "Table Daggerheart" -ErrorAction SilentlyContinue
New-NetFirewallRule -DisplayName "Table Daggerheart" -Direction Inbound -Protocol TCP -LocalPort $port -Action Allow | Out-Null
$action = New-ScheduledTaskAction -Execute $node -Argument "server.js" -WorkingDirectory $dir
$trigger = New-ScheduledTaskTrigger -AtStartup
$settings = New-ScheduledTaskSettingsSet -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit (New-TimeSpan -Seconds 0) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
Register-ScheduledTask -TaskName "Table Daggerheart" -Action $action -Trigger $trigger -Settings $settings -User "SYSTEM" -RunLevel Highest -Force | Out-Null
Start-ScheduledTask -TaskName "Table Daggerheart"
Start-Sleep -Seconds 3
try { Invoke-WebRequest "http://localhost:$port/api/ping" -UseBasicParsing | Out-Null; Write-Host "Serveur en ligne : http://localhost:$port" -ForegroundColor Green }
catch { Write-Host "Le serveur ne repond pas. Lancez DEMARRER.bat pour voir l'erreur." -ForegroundColor Yellow }
